/*
  SuperStepper.cpp - Library for driving stepper motor. 
  Tested with Sparkfun Big Easy Driver.
  Built-in acceleration and deceleration for the stepper
  Created by Timo Karsisto, July 31, 2012.
  Released into the public domain.
 */
#ifndef SuperStepper_h
#define SuperStepper_h

#include "Arduino.h"

class SuperStepper
{
public:
  //constructor with sleep mode enabled
  SuperStepper(byte DIR_PIN, byte STEP_PIN, byte STEPPER_SLEEP_PIN);
  //constructor without sleep mode
  SuperStepper(byte DIR_PIN, byte STEP_PIN);
  //stepper resolution in steps/round
  void setResolution(int stepperResolution);
  //if moving object, configure how many MM is 360 on the stepper
  void setOneRoundInMM(float oneRoundInMM);
  //minumun delay, smaller means more max speed. Normal is around 150
  void setMinUsDelay(int usFactor);
  //rotates given amount of steps, speed should vary from 0.1 to 1
  void rotateSteps(long int steps, float speed);
  //rotates given amount of degrees, speed should vary from 0.1 to 1
  void rotateDeg(float deg, float speed);
  //moves given MM, speed should vary from 0.1 to 1
  void moveMM(float millimeters, float speed);
  //internal but can be used, it will set the motor to sleep
  void sleepMotor();
  //awakes the motor from sleep
  void awakeMotor();
  //Should not be touched. Default value is 8 (smaller value is quicker acceleration). Value around greater than 3 is ok
  void setAccelerationFactor(int accFactor);
  //Should not be touched. Default value is 10 (smaller value is quicker deceleration). Value greater than 3 is ok
  void setDecelerationFactor(int decFactor);
private:
  byte _DIR_PIN;
  byte _STEP_PIN;
  byte _STEPPER_SLEEP_PIN;
  float _oneRoundInMM;
  int _stepperResolution;
  int _usFactor;
  int _accFactor;
  int _decFactor;
};

#endif

